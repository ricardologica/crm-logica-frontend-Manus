
import React from 'react';

function Contas() {
  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Módulo de Contas</h2>
      <p className="text-gray-600">Conteúdo do módulo de Contas será implementado aqui.</p>
    </div>
  );
}

export default Contas;


